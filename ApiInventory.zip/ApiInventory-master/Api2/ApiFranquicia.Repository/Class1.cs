﻿using System;

namespace ApiFranquicia.Repository
{
    public class Class1
    {
    }
}
