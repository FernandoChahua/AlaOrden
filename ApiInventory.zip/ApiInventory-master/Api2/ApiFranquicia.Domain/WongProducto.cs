namespace ApiFranquicia.Domain
{
    public class WongProducto
    {
        public int Id{get;set;}
        public int Stock{get;set;}
        public double Precio{get;set;}
        
    }
}