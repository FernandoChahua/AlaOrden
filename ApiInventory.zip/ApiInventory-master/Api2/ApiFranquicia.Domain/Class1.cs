﻿using System;

namespace ApiFranquicia.Domain
{
    public class Class1
    {
    }
}
